package u4.u5.entregable;

public class Main {
	public static void main(String[] args) {
		Coro coro1 = new Coro("nombreCoro", "nombreAutor", "autorMusica", "autorLetras", "tipoDisfraz", 4, 5);
		Integrante int1 = new Integrante("nombreIntegrante1", "localidadIntegrante1", 18);
		Integrante int2 = new Integrante("nombreIntegrante2", "localidadIntegrante2", 22);
		Integrante int3 = new Integrante("nombreIntegrante3", "localidadIntegrante3", 36);
		
		coro1.insertar_integrante(int1);
		coro1.insertar_integrante(int2);
		coro1.insertar_integrante(int3);
		
		coro1.mostrarLista();
		
		coro1.eliminar_integrante(int3);
		
		System.out.println("-----------------------------------------------------------");
		
		coro1.mostrarLista();
		
		coro1.insertar_integrante(int3);
		
		System.out.println("-----------------------------------------------------------");
		
		coro1.mostrarLista();
		
		System.out.println(coro1.toString());
		
		System.out.println(coro1.cantar_la_presentacion());
		System.out.println(coro1.caminito_del_falla());
		
		coro1.insertar_integrante(int1);
	}
}
