package u4.u5.entregable;

public class Cuarteto extends AgrupacionOficial implements Callejera {
	private int numMiembros;
	
	Cuarteto() {
		
	}
	
	Cuarteto(String nombre, String autor, String autorMusica, String autorLetras, String tipoDisfraz, int numMiembros) {
		this.nombre = nombre;
		this.autor = autor;
		this.autorMusica = autorMusica;
		this.autorLetras = autorLetras;
		this.tipoDisfraz = tipoDisfraz;
		this.numMiembros = numMiembros;
	}
	
	// Implementación del método toString();
	@Override
	public String toString() {
		return "Cuarteto [numMiembros=" + numMiembros + ", puntosObtenidos=" + puntosObtenidos + ", nombre=" + nombre
				+ ", autor=" + autor + ", autorMusica=" + autorMusica + ", autorLetras=" + autorLetras
				+ ", tipoDisfraz=" + tipoDisfraz + "]";
	}

	// Implementación de métodos abstractos (clase heredada)
	@Override
	public String caminito_del_falla() {
		return "El cuarteto '"+this.nombre+"' va caminito del falla";
	}

	@Override
	public String cantar_la_presentacion() {
		return "Cantando la presentación del Cuarteto con nombre '"+this.nombre+"'";
	}

	@Override
	public String mostrar_tipo() {
		return "El Cuarteto '"+this.nombre+"' va de '"+this.tipoDisfraz+"'";
	}
	
	// Implementación de métodos abstractos (interfaz)
	@Override
	public String amo_a_escucha() {
		return "Amo a escucha el Cuarteto '"+this.nombre+"'";
	}
	
	// Implementación de Getters and Setters
	public int getNumMiembros() {
		return numMiembros;
	}

	public void setNumMiembros(int numMiembros) {
		this.numMiembros = numMiembros;
	}
}
