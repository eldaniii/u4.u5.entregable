package u4.u5.entregable;

public class Romancero extends Agrupacion implements Callejera {
	private String tematicaCartelon;
	
	Romancero() {
		
	}
	
	Romancero(String nombre, String autor, String autorMusica, String autorLetras, String tipoDisfraz, String tematicaCartelon) {
		this.nombre = nombre;
		this.autor = autor;
		this.autorMusica = autorMusica;
		this.autorLetras = autorLetras;
		this.tipoDisfraz = tipoDisfraz;
		this.tematicaCartelon = tematicaCartelon;
	}
	
	// Implementación del método toString();
	@Override
	public String toString() {
		return "Romancero [tematicaCartelon=" + tematicaCartelon + ", nombre=" + nombre + ", autor=" + autor
				+ ", autorMusica=" + autorMusica + ", autorLetras=" + autorLetras + ", tipoDisfraz=" + tipoDisfraz
				+ "]";
	}

	// Implementación de métodos abstractos (clase heredada)
	@Override
	public String cantar_la_presentacion() {
		return "Cantando la presentación del Romancero con nombre '"+this.nombre+"'";
	}
	
	@Override
	public String mostrar_tipo() {
		return "El Romancero '"+this.nombre+"' va de '"+this.tipoDisfraz+"'";
	}
	
	// Implementación de métodos abstractos (interfaz)
	@Override
	public String amo_a_escucha() {
		return "Amo a escucha el Romancero '"+this.nombre+"'";
	}
	
	// Implementación de Getters and Setters
	public String getTematicaCartelon() {
		return tematicaCartelon;
	}

	public void setTematicaCartelon(String tematicaCartelon) {
		this.tematicaCartelon = tematicaCartelon;
	}
}
