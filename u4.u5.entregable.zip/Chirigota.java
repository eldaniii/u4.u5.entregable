package u4.u5.entregable;

public class Chirigota extends AgrupacionOficial implements Callejera {
	private int numCuples;

	Chirigota() {
		
	}
	
	Chirigota(String nombre, String autor, String autorMusica, String autorLetras, String tipoDisfraz, int numCuples) {
		this.nombre = nombre;
		this.autor = autor;
		this.autorMusica = autorMusica;
		this.autorLetras = autorLetras;
		this.tipoDisfraz = tipoDisfraz;
		this.numCuples = numCuples;
	}
	
	// Implementación del método toString();
	@Override
	public String toString() {
		return "Chirigota [numCuples=" + numCuples + ", puntosObtenidos=" + puntosObtenidos + ", nombre=" + nombre
				+ ", autor=" + autor + ", autorMusica=" + autorMusica + ", autorLetras=" + autorLetras
				+ ", tipoDisfraz=" + tipoDisfraz + "]";
	}
	
	// Implementación de métodos abstractos (clase heredada)
	@Override
	public String caminito_del_falla() {
		return "La chirigota '"+this.nombre+"' va caminito del falla";
	}

	@Override
	public String cantar_la_presentacion() {
		return "Cantando la presentación de la Chirigota con nombre '"+this.nombre+"'";
	}

	@Override
	public String mostrar_tipo() {
		return "La Chirigota '"+this.nombre+"' va de '"+this.tipoDisfraz+"'";
	}

	// Implementación de métodos abstractos (interfaz)
	@Override
	public String amo_a_escucha() {
		return "Amo a escucha la Chirigota '"+this.nombre+"'";
	}
	
	// Implementación de Getters and Setters
	public int getNumCuples() {
		return numCuples;
	}

	public void setNumCuples(int numCuples) {
		this.numCuples = numCuples;
	}
}
