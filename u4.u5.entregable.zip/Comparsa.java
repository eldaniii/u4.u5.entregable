package u4.u5.entregable;

public class Comparsa extends AgrupacionOficial {
	private String empresaAtrezo;
	
	Comparsa() {
		
	}
	
	Comparsa(String nombre, String autor, String autorMusica, String autorLetras, String tipoDisfraz, String empresaAtrezo) {
		this.nombre = nombre;
		this.autor = autor;
		this.autorMusica = autorMusica;
		this.autorLetras = autorLetras;
		this.tipoDisfraz = tipoDisfraz;
		this.empresaAtrezo = empresaAtrezo;
	}
	
	// Implementación del método toString();
	@Override
	public String toString() {
		return "Comparsa [empresaAtrezo=" + empresaAtrezo + ", puntosObtenidos=" + puntosObtenidos + ", nombre="
				+ nombre + ", autor=" + autor + ", autorMusica=" + autorMusica + ", autorLetras=" + autorLetras
				+ ", tipoDisfraz=" + tipoDisfraz + "]";
	}
	
	// Implementación de métodos abstractos (clase heredada)
	@Override
	public String caminito_del_falla() {
		return "La comparsa '"+this.nombre+"' va caminito del falla";

	}
	
	@Override
	public String cantar_la_presentacion() {
		return "Cantando la presentación de la Comparsa con nombre '"+this.nombre+"'";
	}
	
	@Override
	public String mostrar_tipo() {
		return "La Comparsa '"+this.nombre+"' va de '"+this.tipoDisfraz+"'";
	}
	
	// Implementación de Getters and Setters
	public String getEmpresaAtrezo() {
		return empresaAtrezo;
	}

	public void setEmpresaAtrezo(String empresaAtrezo) {
		this.empresaAtrezo = empresaAtrezo;
	}
}
