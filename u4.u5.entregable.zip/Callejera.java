package u4.u5.entregable;

public interface Callejera {
	public String amo_a_escucha();
}
