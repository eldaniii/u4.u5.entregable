package u4.u5.entregable;

public class Integrante {
	String nombre;
	String localidad;
	int edad;
	int numero_participante;
	
	Integrante(String nombre, String localidad, int edad) {
		this.nombre = nombre;
		this.localidad = localidad;
		this.edad = edad;
	}
	
	// Implementación del método toString();
	@Override
	public String toString() {
		return "Integrante [nombre=" + nombre + ", localidad=" + localidad + ", edad=" + edad + ", numero_participante="
				+ numero_participante + "]";
	}

	// Implementación de Getters and Setters
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getLocalidad() {
		return localidad;
	}

	public void setLocalidad(String localidad) {
		this.localidad = localidad;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public int getNumero_participante() {
		return numero_participante;
	}

	public void setNumero_participante(int numero_participante) {
		this.numero_participante = numero_participante;
	}
}
