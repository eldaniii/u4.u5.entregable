package u4.u5.entregable;

public abstract class Agrupacion {
	protected String nombre;
	protected String autor;
	protected String autorMusica;
	protected String autorLetras;
	protected String tipoDisfraz;
	
	// Definimos métodos abstractos
	public abstract String cantar_la_presentacion();
	public abstract String mostrar_tipo();
	
	// Implementación de Getters and Setters
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public String getAutorMusica() {
		return autorMusica;
	}
	public void setAutorMusica(String autorMusica) {
		this.autorMusica = autorMusica;
	}
	public String getAutorLetras() {
		return autorLetras;
	}
	public void setAutorLetras(String autorLetras) {
		this.autorLetras = autorLetras;
	}
	public String getTipoDisfraz() {
		return tipoDisfraz;
	}
	public void setTipoDisfraz(String tipoDisfraz) {
		this.tipoDisfraz = tipoDisfraz;
	}
	
	public void compareTo() {
		
	}
}
