package u4.u5.entregable;

public abstract class AgrupacionOficial extends Agrupacion {
	protected int puntosObtenidos = 0;
	protected static Integrante[] listaIntegrantes = new Integrante[100];
	protected static int contadorParticipantes = 0;
	protected int num_agrupacion;
	
	public void insertar_integrante(Integrante i) {
		listaIntegrantes[contadorParticipantes] = i;
		i.setNumero_participante(contadorParticipantes);
		contadorParticipantes++;
	}
	
	public boolean eliminar_integrante(Integrante i) {
		Integrante[] tmp = new Integrante[listaIntegrantes.length];
		int cont = 0;
		
		for (int j=0; j<contadorParticipantes; j++) {
			if (!(j==i.numero_participante)) {
				tmp[cont]=listaIntegrantes[j];
				cont++;
			}
		}
		
		contadorParticipantes=cont;
		System.arraycopy(tmp, 0, listaIntegrantes, 0, tmp.length);
		
		for (int k=0; k<listaIntegrantes.length; k++) {
			if (!(listaIntegrantes[k]==tmp[k])) return false;
				
		}
		
		return true;
	}
	
	public void mostrarLista() {
		for (int i=0; i<contadorParticipantes; i++) {
			System.out.println(i+": "+listaIntegrantes[i].toString());
		}
	}
	
	public abstract String caminito_del_falla();
	
	// Implementación de Getters and Setters
	public int getPuntosObtenidos() {
		return puntosObtenidos;
	}
	
	public void setPuntosObtenidos(int puntosObtenidos) {
		this.puntosObtenidos = puntosObtenidos;
	}

	public int getNumAgrupacion() {
		return num_agrupacion;
	}

	public void setNumAgrupacion(int numAgrupacion) {
		this.num_agrupacion = numAgrupacion;
	}
}
