package u4.u5.entregable;

public class Coro extends AgrupacionOficial {
	private int numBandurrias;
	private int numGuitarras;
	
	Coro(){
		
	}
	
	Coro(String nombre, String autor, String autorMusica, String autorLetras, String tipoDisfraz, int numBandurrias, int numGuitarras) {
		this.nombre = nombre;
		this.autor = autor;
		this.autorMusica = autorMusica;
		this.autorLetras = autorLetras;
		this.tipoDisfraz = tipoDisfraz;
		this.numBandurrias = numBandurrias;
		this.numGuitarras = numGuitarras;
	}
	
	// Implementación del método toString();
	@Override
	public String toString() {
		return "Coro [numBandurrias=" + numBandurrias + ", numGuitarras=" + numGuitarras + ", puntosObtenidos="
				+ puntosObtenidos + ", nombre=" + nombre + ", autor=" + autor + ", autorMusica=" + autorMusica
				+ ", autorLetras=" + autorLetras + ", tipoDisfraz=" + tipoDisfraz + "]";
	}
	
	// Implementación de métodos abstractos (clase heredada)
	@Override
	public String cantar_la_presentacion() {
		return "Cantando la presentación del Coro con nombre '"+this.nombre+"'";
	}

	@Override
	public String mostrar_tipo() {
		return "El Coro '"+this.nombre+"' va de '"+this.tipoDisfraz+"'";
	}

	@Override
	public String caminito_del_falla() {
		return "El coro '"+this.nombre+"' va caminito del falla";
	}
	
	// Implementación de Getters and Setters
	public int getNumBandurrias() {
		return numBandurrias;
	}

	public void setNumBandurrias(int numBandurrias) {
		this.numBandurrias = numBandurrias;
	}

	public int getNumGuitarras() {
		return numGuitarras;
	}

	public void setNumGuitarras(int numGuitarras) {
		this.numGuitarras = numGuitarras;
	}
}
