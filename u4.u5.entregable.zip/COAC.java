package u4.u5.entregable;

public class COAC {
	protected static AgrupacionOficial[] listaAgrupaciones = new AgrupacionOficial[100];
	protected static int contadorAgrupaciones = 0;
	
	public void inscribir_agrupacion(AgrupacionOficial a) {
		listaAgrupaciones[contadorAgrupaciones] = a;
		contadorAgrupaciones++;
		a.setNumAgrupacion(contadorAgrupaciones);
		contadorAgrupaciones++;
	}
	
	public boolean eliminar_agrupacion(AgrupacionOficial a) {
		AgrupacionOficial[] tmp = new AgrupacionOficial[listaAgrupaciones.length];
		int cont = 0;
		
		for (int j=0; j<contadorAgrupaciones; j++) {
			if (!(j==a.num_agrupacion)) {
				tmp[cont]=listaAgrupaciones[j];
				cont++;
			}
		}
		
		contadorAgrupaciones=cont;
		System.arraycopy(tmp, 0, listaAgrupaciones, 0, tmp.length);
		
		for (int k=0; k<listaAgrupaciones.length; k++) {
			if (!(listaAgrupaciones[k]==tmp[k])) return false;
				
		}
		
		return false;
	}
	
	public int compareTo(AgrupacionOficial a1, AgrupacionOficial a2) {
		 return a1.puntosObtenidos > a2.puntosObtenidos ? 1 : a1.puntosObtenidos < a1.puntosObtenidos ? -1 : 0;
	 }
	
	void ordenar_por_puntos() {
		
	}

	void ordenar_por_nombre() {
		
	}
	
	void ordenar_por_autor() {
		
	}
}
